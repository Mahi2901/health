package com.helth.helthcare.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.helth.helthcare.model.CityModel;

@Repository
public interface Repocity extends JpaRepository<CityModel, Long> {

	@Query(value="select * from city where stateid=?1",nativeQuery=true)
	List<CityModel> getCity(long sid);
}
