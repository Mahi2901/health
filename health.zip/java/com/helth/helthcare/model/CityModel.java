package com.helth.helthcare.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="city")
public class CityModel {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long cityid;
	private String cityname;
	
	@ManyToOne
	@JoinColumn(name="stateid")
	private StateModel statemodel;

	public long getCityid() {
		return cityid;
	}

	public void setCityid(long cityid) {
		this.cityid = cityid;
	}

	public String getCityname() {
		return cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

	public StateModel getStatemodel() {
		return statemodel;
	}

	public void setStatemodel(StateModel statemodel) {
		this.statemodel = statemodel;
	}

	
	
	
}
