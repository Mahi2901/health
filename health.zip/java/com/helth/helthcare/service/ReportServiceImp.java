package com.helth.helthcare.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.helth.helthcare.model.ReportModel;
import com.helth.helthcare.repository.ReportRepo;

@Service
@Transactional
public class ReportServiceImp implements ReportService {

	@Autowired
	ReportRepo reportRepo;
	
	@Override
	public ReportModel save(ReportModel report) {
		// TODO Auto-generated method stub
		return reportRepo.save(report);
	}

	@Override
	public ReportModel findById(long id) {
		// TODO Auto-generated method stub
		return reportRepo.findById(id).orElse(null);
	}

	@Override
	public List<ReportModel> findByDoctorId(long id) {
		// TODO Auto-generated method stub
		return reportRepo.findByDoctortId(id);
	}

	@Override
	public List<ReportModel> findByPatientId(long id) {
		// TODO Auto-generated method stub
		return reportRepo.findByPatientId(id);
	}

}
