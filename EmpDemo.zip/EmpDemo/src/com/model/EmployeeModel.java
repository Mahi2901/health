package com.model;

public class EmployeeModel {
	public long Empid;
	public String Ename;
	public String Eaddress;
	public String Egender;
	public double ESalary;

	public long getEmpid() {
		return Empid;
	}

	public void setEmpid(long empid) {
		Empid = empid;
	}

	public String getEname() {
		return Ename;
	}

	public void setEname(String ename) {
		Ename = ename;
	}

	public String getEaddress() {
		return Eaddress;
	}

	public void setEaddress(String eaddress) {
		Eaddress = eaddress;
	}

	public String getEgender() {
		return Egender;
	}

	public void setEgender(String egender) {
		Egender = egender;
	}

	public double getESalary() {
		return ESalary;
	}

	public void setESalary(double esalary) {
		ESalary = esalary;
	}

}
