package program;

public class ForloopExtra
{

	public static void main(String[] args)
	{
		int i;
		for (i = 0; i <= 10; i++);
		{
			System.out.println(i);
		}
		System.out.println(i);
	}
}
