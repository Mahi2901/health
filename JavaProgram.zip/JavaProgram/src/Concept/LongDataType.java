/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Concept;


public class LongDataType 
{
    public static void main(String[] args) 
    {
        long x=5;
        long y=10;
        
        System.out.println("Foo" + x + y);
        System.out.println(x + y + "Foo");
        System.out.println();
        
    }
    
}
 