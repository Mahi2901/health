package test;

import java.awt.Choice;

public class Te {
    static int i=1;
    
    public static void main(String[] args) {
//       int x=0,y=0,z=0 ;
//       x=(++x + y--)*z++;
//       System.out.println("X is : " + x);

//        System.out.println(25 / 4.0);
//        System.out.println(25.0 / 4.0);
//        System.out.println(25.0 / 4);
//        int height = 10, width = 10, length = 20;
//        System.out.println("Volume is "
//                + (width * height * length));
//        int i;
//        for (i = 1; i < 6; i++) {
//            if (i > 3) {
//                continue;
//            }
//            System.out.println(i);
//        }
//        int i,j;
//        for(i=0,j=0;i<3;i++,j++){
//            System.out.println(i + j);
//        }
//        Float f1 = new Float("3.2");
//        float f = f1.floatValue();
//        System.out.println(f);
//        int rates[] = {10, 20, 30};
//        System.out.println(rates.length);
//        String str1 ="one";; 
//        String str2 = "two";
//        System.out.println(str1.concat(str2)==(str1 + str2));
//        System.out.println(str1.concat(str2).equals(str1 + str2));
//        String str ="Hello";
//        str.insert(2, 'k');
//        System.out.println(str);
//        int x[] = new int[3];
//        System.out.println(x[0]);
//        String s1 ="SRIRAMA"; 
//        String s2 = "RAMA";           // compile error
//        String s3 = s1 – s2;
//        System.out.println(s3);
//        byte charArray[] ={'S','C','J','P' };  
//        System.out.println(charArray[0]);       // 83
//        int i=0;
//        i = i++ + i;
//        System.out.println("I = " +i);    //1
        System.out.println(i +",");
        i=i+2;
        
        System.out.println(i);
        
    }
  
}
