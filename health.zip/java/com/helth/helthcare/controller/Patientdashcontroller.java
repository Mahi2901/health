package com.helth.helthcare.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.helth.helthcare.model.Booking;
import com.helth.helthcare.model.ReportModel;
import com.helth.helthcare.model.User;
import com.helth.helthcare.repository.BookingRepo;
import com.helth.helthcare.repository.PatientRepo;
import com.helth.helthcare.repository.UserRepo;
import com.helth.helthcare.service.BookingService;
import com.helth.helthcare.service.ReportService;
import com.helth.helthcare.servlet.JavaIntegrationKit;

@Controller
@RequestMapping("/Patientdash")
public class Patientdashcontroller 
{
	@Autowired
	private JavaMailSender sender;
		
	@Autowired
	PatientRepo patientRepo;
	
	@Autowired
	UserRepo userRepo;
	
	@Autowired
	ReportService reportService;
	
	
	@Autowired
	BookingRepo bookingRepo;
	
	@Autowired
	BookingService bookingService;
	

	@RequestMapping(value = { "", "/", "index" })
	public String index1() {
		return "Patientdash/index";
	}

	@RequestMapping("/{page}")
	public String page1(@PathVariable String page) {
		return "Patientdash/"+page;
	}
	
	@RequestMapping("/PatientRecord/{id}")
	@ResponseBody
	public User findPatient(@PathVariable long id) {
		return userRepo.findById(id).orElse(null);
	}
	
	@RequestMapping("/bookappointment")
	@ResponseBody
	public ModelAndView bookAppointment(@ModelAttribute Booking book) {
		book.setPaymentstatus("fail");
		book=bookingService.save(book);
		ModelAndView mv = new ModelAndView("Patientdash/payfees");
		 
		mv.addObject("list", book);
		 
		
		return mv;
	}
	
	@RequestMapping("/myServlet")
	public void payment(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 JavaIntegrationKit integrationKit = new JavaIntegrationKit();
	        Map<String, String> values = integrationKit.hashCalMethod(request, response);
	        
	        
	        System.out.println("------------------");
	        System.out.println("------------------"+values.get("key").trim());
	        
	        
	        PrintWriter writer = response.getWriter();
	// build HTML code
	        String htmlResponse = "<html> <body> \n"
	                + "      \n"
	                + "  \n"
	                + "  <h1>PayUForm </h1>\n"
	                + "  \n" + "<div>"
	                + "        <form id=\"payuform\" action=\"" + values.get("action") + "\"  name=\"payuform\" method=POST >\n"
	                + "      <input type=\"hidden\" name=\"key\" value=" + values.get("key").trim() + ">"
	                + "      <input type=\"hidden\" name=\"hash\" value=" + values.get("hash").trim() + ">"
	                + "      <input type=\"hidden\" name=\"txnid\" value=" + values.get("txnid").trim() + ">"
	                + "      <table>\n"
	                + "        <tr>\n"
	                + "          <td><b>Mandatory Parameters</b></td>\n"
	                + "        </tr>\n"
	                + "        <tr>\n"
	                + "         <td>Amount: </td>\n"
	                + "          <td><input name=\"amount\" value=" + values.get("amount").trim() + " /></td>\n"
	                + "          <td>First Name: </td>\n"
	                + "          <td><input name=\"firstname\" id=\"firstname\" value=" + values.get("firstname").trim() + " /></td>\n"
	                + "        <tr>\n"
	                + "          <td>Email: </td>\n"
	                + "          <td><input name=\"email\" id=\"email\" value=" + values.get("email").trim() + " /></td>\n"
	                + "          <td>Phone: </td>\n"
	                + "          <td><input name=\"phone\" value=" + values.get("phone") + " ></td>\n"
	                + "        </tr>\n"
	                + "        <tr>\n"
	                + "          <td>Product Info: </td>\n"
	                + "<td><input name=\"productinfo\" value=" + values.get("productinfo").trim() + " ></td>\n"
	                + "        </tr>\n"
	                + "        <tr>\n"
	                + "          <td>Success URI: </td>\n"
	                + "          <td colspan=\"3\"><input name=\"surl\"  size=\"64\" value=" + values.get("surl") + "></td>\n"
	                + "        </tr>\n"
	                + "        <tr>\n"
	                + "          <td>Failure URI: </td>\n"
	                + "          <td colspan=\"3\"><input name=\"furl\" value=" + values.get("furl") + " size=\"64\" ></td>\n"
	                + "        </tr>\n"
	                + "\n"
	                + "        <tr>\n"
	                + "          <td colspan=\"3\"><input type=\"hidden\" name=\"service_provider\" value=\"payu_paisa\" /></td>\n"
	                + "        </tr>\n"
	                + "             <tr>\n"
	                + "          <td><b>Optional Parameters</b></td>\n"
	                + "        </tr>\n"
	                + "        <tr>\n"
	                + "          <td>Last Name: </td>\n"
	                + "          <td><input name=\"lastname\" id=\"lastname\" value=" + values.get("lastname") + " ></td>\n"
	                + "          <td>Cancel URI: </td>\n"
	                + "          <td><input name=\"curl\" value=" + values.get("curl") + " ></td>\n"
	                + "        </tr>\n"
	                + "        <tr>\n"
	                + "          <td>Address1: </td>\n"
	                + "          <td><input name=\"address1\" value=" + values.get("address1") + " ></td>\n"
	                + "          <td>Address2: </td>\n"
	                + "          <td><input name=\"address2\" value=" + values.get("address2") + " ></td>\n"
	                + "        </tr>\n"
	                + "        <tr>\n"
	                + "          <td>City: </td>\n"
	                + "          <td><input name=\"city\" value=" + values.get("city") + "></td>\n"
	                + "          <td>State: </td>\n"
	                + "          <td><input name=\"state\" value=" + values.get("state") + "></td>\n"
	                + "        </tr>\n"
	                + "        <tr>\n"
	                + "          <td>Country: </td>\n"
	                + "          <td><input name=\"country\" value=" + values.get("country") + " ></td>\n"
	                + "          <td>Zipcode: </td>\n"
	                + "          <td><input name=\"zipcode\" value=" + values.get("zipcode") + " ></td>\n"
	                + "        </tr>\n"
	                + "          <td>UDF1: </td>\n"
	                + "          <td><input name=\"udf1\" value=" + values.get("udf1") + "></td>\n"
	                + "          <td>UDF2: </td>\n"
	                + "          <td><input name=\"udf2\" value=" + values.get("udf2") + "></td>\n"
	                + " <td><input name=\"hashString\" value=" + values.get("hashString") + "></td>\n"
	                + "          <td>UDF3: </td>\n"
	                + "          <td><input name=\"udf3\" value=" + values.get("udf3") + " ></td>\n"
	                + "          <td>UDF4: </td>\n"
	                + "          <td><input name=\"udf4\" value=" + values.get("udf4") + " ></td>\n"
	                + "          <td>UDF5: </td>\n"
	                + "          <td><input name=\"udf5\" value=" + values.get("udf5") + " ></td>\n"
	                + "          <td>PG: </td>\n"
	                + "          <td><input name=\"pg\" value=" + values.get("pg") + " ></td>\n"
	                + "        <td colspan=\"4\"><input type=\"submit\" value=\"Submit\"  /></td>\n"
	                + "      \n"
	                + "    \n"
	                + "      </table>\n"
	                + "    </form>\n"
	                + " <script> "
	                + " document.getElementById(\"payuform\").submit(); "
	                + " </script> "
	                + "       </div>   "
	                + "  \n"
	                + "  </body>\n"
	                + "</html>";
	// return response
	        writer.println(htmlResponse);

	}
	
	@RequestMapping("/success")
	public String paymentSuccess(HttpServletRequest request, HttpServletResponse response,Booking book) {
		
		long bookid = Long.valueOf(request.getParameter("productinfo").toString());
		System.out.println(bookid);
		Booking book1 = bookingService.findBybookid(bookid);
		
		book1.setPaymentstatus("success"); 
		
		
		   MimeMessage message = sender.createMimeMessage();
		   MimeMessageHelper helper = new MimeMessageHelper(message);
		   try {
				helper.setTo(book1.getPatientModel().getUsers().getEmail());
				helper.setText("Your Appointment is confirm with Ticket No : "+book1.getBookingid()
								+ "    Hospital Name is : "+ book1.getHospitalModel().getHospitalname()
								+ "    Deparment is : " + book1.getDepartmentModel().getDepartmentname()
								+ "    Appointment Date is : " + book1.getDate()
								+ "    Payment Status : Success"
						
						);
				helper.setSubject("Mail For security info");
			} catch (MessagingException e) {
				e.printStackTrace();
				return "Error while sending mail ..";
			}
			sender.send(message);
			
			bookingRepo.save(book1);
		return "redirect:/Patientdash/index"; 
		
	}
	
	@RequestMapping("/PatientAppointment/{id}")
	@ResponseBody
	public List<Booking> findPatientAppointment(@PathVariable long id) 
	{
		/*
		 * ModelAndView mv = new ModelAndView("Patientdash/appointment-view");
		 * mv.addObject("list", bookingRepo.getPatientAppointment(id));
		 */
		return bookingService.getPatientAppointment(id);
	}
	
	@RequestMapping("/viewReport/{id}")
	@ResponseBody
	public List<ReportModel> findPatientReport(@PathVariable("id") long id) 
	{
		return reportService.findByPatientId(id);
	}

}
