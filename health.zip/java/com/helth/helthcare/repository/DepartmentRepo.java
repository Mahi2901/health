package com.helth.helthcare.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.helth.helthcare.model.DepartmentModel;

@Repository
public interface DepartmentRepo extends JpaRepository<DepartmentModel, Long> 
{
	@Query(value="select * from department where hospitalid=?1",nativeQuery=true)
	List<DepartmentModel> getDepartment(long id);
	
	@Query(value="select count(*) from department where hospitalid=?1",nativeQuery=true)
	long getDepartmentcount(long id);

}
