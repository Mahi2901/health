package com.action;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.connection.DBConnection;
import com.model.SkillModel;

@WebServlet("/SkillAction")
public class SkillAction extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public SkillAction() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<SkillModel> skillModelArrayList = new ArrayList<SkillModel>();

		SkillModel skillModel = null;
		DBConnection dbConnection = null;
 		Connection connection = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/sargam","root","root");
			stmt = connection.createStatement();
			String sql = "Select *  from Skillmaster ";
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				skillModel = new SkillModel();
				skillModel.setSkillId(rs.getInt("skillId"));
				skillModel.setName(rs.getString("name"));
				skillModelArrayList.add(skillModel);
																																	
				System.out.println(skillModel.getName());
				System.out.println(skillModel.getSkillId());

			}

			request.setAttribute("skillModelArrayList", skillModelArrayList);
			RequestDispatcher rd = request.getRequestDispatcher("Employee.jsp");
			rd.forward(request, response);

			System.out.println(skillModelArrayList.size());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

}
