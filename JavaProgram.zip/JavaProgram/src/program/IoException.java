package program;

class IoException
{

}
