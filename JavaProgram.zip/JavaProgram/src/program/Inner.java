package program;

public class Inner
{
	private int a;

	class de
	{
		public void se()
		{
			System.out.println(a);
		}
	}
	public static void main(String[] args)
	{

	}
}
