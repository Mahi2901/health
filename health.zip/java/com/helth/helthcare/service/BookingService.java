package com.helth.helthcare.service;

import java.util.List;

import com.helth.helthcare.model.Booking;

public interface BookingService 
{
	public Booking save(Booking book);
	public Booking findBybookid(long id);
	public List<Booking> getDoctorAppointment(long id);
	public List<Booking> getPatientAppointment(long id);
}
