package com.helth.helthcare.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.helth.helthcare.model.CityModel;
import com.helth.helthcare.model.DepartmentModel;
import com.helth.helthcare.model.DoctorModel;
import com.helth.helthcare.model.HospitalModel;
import com.helth.helthcare.model.StateModel;
import com.helth.helthcare.repository.BookingRepo;
import com.helth.helthcare.repository.DepartmentRepo;
import com.helth.helthcare.repository.DoctorRepo;
import com.helth.helthcare.repository.HospitalRepo;
import com.helth.helthcare.repository.Repocity;
import com.helth.helthcare.repository.Repostate;
import com.helth.helthcare.service.ArticalService;
import com.helth.helthcare.util.JasperExporter;


@Controller
@RequestMapping("/Manage")
public class Statecontroller {
	
	HashMap jasperParameter;
	@Autowired
	Repostate srepo;

	@Autowired
	HospitalRepo hospitalRepo;
	
	@Autowired
	DepartmentRepo departmentRepo;
	
	
	@Autowired
	ArticalService articalService;
	
	
	@Autowired
	DoctorRepo doctorRepo;
	
	@Autowired
	BookingRepo bookingRepo;
	
	
	@Autowired
	Repocity crepo;

	@RequestMapping("/state")
	@ResponseBody
	public List<StateModel> State() {

		return srepo.findAll();
	}
	
	@RequestMapping("/city/{sid}")
	@ResponseBody
	public List<CityModel> city(@PathVariable long sid) 
	{
		return crepo.getCity(sid);
	}
	
	@RequestMapping("/getHospital")
	@ResponseBody
	public List<HospitalModel> getHospital() {

		return hospitalRepo.findAll();
	}
	
	@RequestMapping("/getDepartment/{id}")
	@ResponseBody
	public List<DepartmentModel> getDepartment(@PathVariable long id) 
	{
		return departmentRepo.getDepartment(id);
	}
	
	@RequestMapping("/getDoctor/{id}")
	@ResponseBody
	public List<DoctorModel> getDoctor(@PathVariable long id) 
	{
		return doctorRepo.getDoctor(id);
	}
	
	@RequestMapping("/getDoctorDetail/{id}")
	@ResponseBody
	public DoctorModel  getDoctorDetail(@PathVariable long id) 
	{
		return doctorRepo.getDoctorDetail(id);
	}
	@RequestMapping("/getAppointment/{id}")
	@ResponseBody
	public long  getAppointment(@PathVariable long id) 
	{
		return bookingRepo.getAppointment(id);
	}
	@RequestMapping("/getDepartmentCount/{id}")
	@ResponseBody
	public long  getDepartmentCount(@PathVariable long id) 
	{
		return departmentRepo.getDepartmentcount(id);
	}
	
	@RequestMapping("/getDoctorCount/{id}")
	@ResponseBody
	public long  getDoctorCount(@PathVariable long id) 
	{
		return doctorRepo.getDoctorCount(id);
	}
	
	/*
	@RequestMapping("/date")
	@ResponseBody
	public String date() 
	{
		DateFormat fdate=new SimpleDateFormat("yyyy/mm/dd HH:mm:ss");
		Date d = new Date();
		return fdate.format(d);
	}
	*/
	@RequestMapping("/FindArtical/{type}")
	public String findArtical(@PathVariable("type") String type,Model m) 
	{
		
		m.addAttribute("articalList", articalService.findByType(type));
		return "Patienthome/Article-View";
	}
	@RequestMapping("/getreport/{id}/pdf")
	@ResponseBody
	public void reportpdf(@PathVariable long id, HttpServletRequest request,HttpServletResponse response) 
	{
		jasperParameter = new HashMap();
		jasperParameter.put("reportId", id);
		JasperExporter jasperExporter = new JasperExporter();
		String Path = "";
		Path = request.getSession().getServletContext().getRealPath("/")+"WEB-INF"+System.getProperty("file.separator")+"jsp"+System.getProperty("file.separator")+"Report";
		System.out.println(Path);
		try {
			jasperExporter.jasperExporterPDF(jasperParameter,Path + System.getProperty("file.separator")+"Report.jrxml", "Report", response);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
