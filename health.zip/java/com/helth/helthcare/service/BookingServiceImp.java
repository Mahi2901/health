package com.helth.helthcare.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.helth.helthcare.model.Booking;
import com.helth.helthcare.model.HospitalModel;
import com.helth.helthcare.repository.BookingRepo;
import com.helth.helthcare.repository.HospitalRepo;

@Service
@Transactional
public class BookingServiceImp implements BookingService 
{
	@Autowired
	BookingRepo bookingRepo;
	
	@PersistenceContext
	EntityManager entityManager;
	

	@Override
	public Booking save(Booking book) 
	{
		Booking book1 =  bookingRepo.save(book);
		entityManager.refresh(book);
		return book1;
	}

	@Override
	public List<Booking> getDoctorAppointment(long id) {
		
		return bookingRepo.getDoctorAppointment(id);
	}

	@Override
	public List<Booking> getPatientAppointment(long id) {
		
		return bookingRepo.getPatientAppointment(id);
	}

	@Override
	public Booking findBybookid(long id) {
		// TODO Auto-generated method stub
		return bookingRepo.findById(id).orElse(null);
	}
	

}
