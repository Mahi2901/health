package com.helth.helthcare.service;

import org.springframework.web.multipart.MultipartFile;

import com.helth.helthcare.model.PatientModel;
public interface PatientService 
{
	public PatientModel save(PatientModel patient);
	public PatientModel findOne(long id);
	public void delete(PatientModel patient);
	public PatientModel updatePatient(MultipartFile file,long id);
	public void updatepassword(String password,long id);

}
