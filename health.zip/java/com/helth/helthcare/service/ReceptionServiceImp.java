package com.helth.helthcare.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.helth.helthcare.model.ReceptionModel;
import com.helth.helthcare.repository.ReceptionRepo;
@Service
@Transactional
public class ReceptionServiceImp implements ReceptionService {

	@Autowired
	ReceptionRepo recaptionRepo;

	@Override
	public ReceptionModel save(ReceptionModel r) {
		// TODO Auto-generated method stub
		return recaptionRepo.save(r);
	}

	@Override
	public ReceptionModel findOne(long id) {
		// TODO Auto-generated method stub
		return recaptionRepo.findById(id).orElse(null);
	}

	@Override
	public void delete(long id) {
		recaptionRepo.deleteById(id);
		
	}

	
	
	
}
