package com.helth.helthcare.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name="hospital")
public class HospitalModel {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long hospitalid;
	private String hospitalname;
	private String address;
	@ManyToOne
	@JoinColumn(name="stateid")
	private StateModel stateModel;
	
	@ManyToOne
	@JoinColumn(name="cityid")
	private CityModel cityModel;
	

	@JsonIgnore
	@OneToOne(mappedBy="hospitalModel")
	private ReceptionModel recaptionModel;

	public long getHospitalid() {
		return hospitalid;
	}

	public void setHospitalid(long hospitalid) {
		this.hospitalid = hospitalid;
	}

	public String getHospitalname() {
		return hospitalname;
	}

	public void setHospitalname(String hospitalname) {
		this.hospitalname = hospitalname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	

	public StateModel getStateModel() {
		return stateModel;
	}

	public void setStateModel(StateModel stateModel) {
		this.stateModel = stateModel;
	}

	public CityModel getCityModel() {
		return cityModel;
	}

	public void setCityModel(CityModel cityModel) {
		this.cityModel = cityModel;
	}

	public ReceptionModel getRecaptionModel() {
		return recaptionModel;
	}

	public void setRecaptionModel(ReceptionModel recaptionModel) {
		this.recaptionModel = recaptionModel;
	}
	
	
	
	
}
