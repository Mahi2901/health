package com.helth.helthcare.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.helth.helthcare.repository.DoctorRepo;
import com.helth.helthcare.repository.HospitalRepo;
import com.helth.helthcare.repository.PatientRepo;

@Controller
@RequestMapping("/Doctor1")
public class Doctor
{

	
	@Autowired
	PatientRepo patientRepo;
	
	@Autowired
	HospitalRepo hospitalRepo;
	
	@Autowired
	DoctorRepo doctorRepo;
	
	@RequestMapping(value = { "", "/", "index" })
	public String index1() 
	{
		return "Doctor/index";
	}

	@RequestMapping("/{page}")
	public String page1(@PathVariable String page) 
	{
		return "Doctor/"+page;
	}
	/*
	@RequestMapping("/AppointmentTable")
	public ModelAndView appointmentTable() 
	{
		ModelAndView mv = new ModelAndView("/Doctor/AppointmentTable");
		mv.addObject("list", bookAppointRepo.findAll());
		return mv;
	}
*/
}
