package com.helth.helthcare.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.helth.helthcare.model.ArticalModel;
import com.helth.helthcare.model.Booking;
import com.helth.helthcare.model.DoctorModel;
import com.helth.helthcare.model.ReportModel;
import com.helth.helthcare.model.User;
import com.helth.helthcare.repository.ArticalRepo;
import com.helth.helthcare.repository.BookingRepo;
import com.helth.helthcare.repository.DepartmentRepo;
import com.helth.helthcare.repository.DoctorRepo;
import com.helth.helthcare.repository.HospitalRepo;
import com.helth.helthcare.repository.PatientRepo;
import com.helth.helthcare.repository.ReceptionRepo;
import com.helth.helthcare.repository.RoleRepo;
import com.helth.helthcare.repository.UserRepo;
import com.helth.helthcare.service.ArticalService;
import com.helth.helthcare.service.PatientService;
import com.helth.helthcare.service.ReportService;

@Controller
@RequestMapping("/Doctor")
public class Doctore 
{
	BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
	private static String UPLOADED_FOLDER = "E://workspace//helthcare//src//main//resources//static//Profiles//";
	private static String UPLOADED_ARTICAL = "E://workspace//helthcare//src//main//resources//static//Articles//";

	
	
	@Autowired
	PatientRepo patientRepo;
	
	@Autowired
	PatientService patientService;
	
	@Autowired
	HospitalRepo hospitalRepo;
	
	@Autowired
	RoleRepo roleRepo;
	
	@Autowired
	ArticalRepo articalRepo;
	
	@Autowired
	ArticalService articalService;
	
	@Autowired
	ReportService reportService;
	
	@Autowired
	DoctorRepo doctorRepo;
	
	@Autowired
	ReceptionRepo recaptionRepo;
	
	@Autowired
	UserRepo userRepo;
	
	@Autowired
	BookingRepo bookingRepo;
	
	@Autowired
	DepartmentRepo departmentRepo;
	
	@RequestMapping(value={"", "/", "index"})
	public String he() {
		return "Doctor/index";
	}
	@RequestMapping("{page}")
	public String page(@PathVariable String page) {
	    return  "Doctor/" + page; //defect-details.html page name to open it
	}
	
	@RequestMapping("/Doctorrecord/{id}")
	@ResponseBody
	public User findDoctor(@PathVariable long id) 
	{
		return userRepo.findById(id).orElse(null);
	}
	
	@RequestMapping("/changepassword")
	public String changePassword(@RequestParam("uid") long id,@RequestParam("password") String password,Model model) 
	{
		User user = userRepo.findById(id).orElse(null);
		
		user.setPassword(passwordEncoder.encode(password));
		userRepo.save(user);
		model.addAttribute("message", "Password Successfully Updated");
		
		return "Doctor/Change-password";
	}
	
	@RequestMapping("/uploadImage")
	public String imageUpload(@RequestParam("uid") long id, @RequestParam("file") MultipartFile file) 
	{
		DoctorModel doctor = doctorRepo.findById(id).orElse(null);
		System.out.println(id);
		if (file.isEmpty()) {
            
            return "redirect:/Doctor/Imageupload";
        }

        try {

            // Get the file and save it somewhere
            byte[] bytes = file.getBytes();
            Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
            Files.write(path, bytes);

        } catch (IOException e) {
            e.printStackTrace();
        }
        String image = file.getOriginalFilename();
        System.out.println(image);
        doctor.setImage(image);
        doctorRepo.save(doctor);
		
		return "redirect:/Doctor/index";
	}
	
	
	@RequestMapping("/Articleadd")
	public String addArtical(@ModelAttribute ArticalModel artical,@RequestParam("file") MultipartFile file) 
	{
		
		if (file.isEmpty()) {
            
            return "redirect:/Doctor/Article";
        }else {

        try {

            // Get the file and save it somewhere
            byte[] bytes = file.getBytes();
            Path path = Paths.get(UPLOADED_ARTICAL + file.getOriginalFilename());
            Files.write(path, bytes);

        } catch (IOException e) {
            e.printStackTrace();
        }
        String image = file.getOriginalFilename();
        artical.setImage(image);
        
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
    	Date date = new Date();
    	artical.setDate(dateFormat.format(date));
    	
        articalService.save(artical);
		
		return "redirect:/Doctor/Article";
        }
	}
	
	@RequestMapping("/ViewAppointment/{id}")
	@ResponseBody
	public List<Booking> findDoctorAppointment(@PathVariable long id) 
	{
		return bookingRepo.getDoctorAppointment(id);
	}
	
	@RequestMapping(value = "/View-Report" , method = RequestMethod.GET)
	public ModelAndView findPatientReport(@RequestParam("id") long id,Model m) 
	{
		
		
		ModelAndView mv = new ModelAndView("Doctor/View-Report");
		mv.addObject("list", reportService.findByPatientId(id));
		return mv;
	}
	
	@RequestMapping(value = "/View-Patient", method = RequestMethod.GET)
	public ModelAndView findPatientDetails(@RequestParam("id") long id,Model m) 
	{
		
		ModelAndView mv = new ModelAndView("Doctor/View-Patient");
		mv.addObject("list", patientService.findOne(id));
		return mv;
	}
	
	@RequestMapping(value = "/Write-Report", method = RequestMethod.GET)
	public ModelAndView findPatient(@RequestParam("id") long id,Model m) 
	{
		
		ModelAndView mv = new ModelAndView("Doctor/Write-Report");
		mv.addObject("list", patientService.findOne(id));
		return mv;
	}
	
	@RequestMapping(value = "/Report", method = RequestMethod.POST)
	public String saveReport(@ModelAttribute ReportModel report,Model m) 
	{
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		report.setDate(dateFormat.format(date));
		reportService.save(report);
		m.addAttribute("message","Report uploaded");
		long id=report.getPatientModel().getPatientid();
		return "redirect:/Doctor/Write-Report?id="+id;
	}

}
