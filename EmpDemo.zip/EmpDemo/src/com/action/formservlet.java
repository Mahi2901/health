package com.action;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.connection.DBConnection;
import com.model.EmployeeModel;

@WebServlet("/formservlet")
public class formservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public formservlet() {
		// TODO Auto-generated constructor stub
	}

	private void update(EmployeeModel employeeModel, String skillIds[],HttpServletRequest request,HttpServletResponse response) {
	//	HttpServletRequest request=null;
	//	HttpServletResponse response=null;
		Connection connection = null;
		Statement stmt = null;
		ResultSet rs = null;
		long eid= employeeModel.Empid;
		String ename= employeeModel.Ename;
		String add= employeeModel.Eaddress;
		String gender= employeeModel.Egender;
		double sal= employeeModel.ESalary;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/sargam","root","root");
			
			stmt = connection.createStatement();
		
			// int i= stmt.executeUpdate("insert into
			// Employee(Empid,Ename,Eaddress,Egender,ESalary)
			// values('"+eid+"','"+ename+"','"+add+"','"+gender+"','"+sal+"')"
			// ,Statement.RETURN_GENERATED_KEYS);

			
			//System.out.println("gggggggggggggggggggg");
			stmt.executeUpdate("update Employee set Ename='"+ename+"',Eaddress='"+add+"',Egender='"+gender+"',Esalary="+sal+" where Empid="+eid+"");
			
			//System.out.println("sddddddddddddddddddd");
			
			// select * from Employee,EmployeeSkill,SkillMaster where
			// Employee.Empid=EmployeeSkill.Empid and
			// SkillMaster.skillId=EmployeeSkill.Skillid
			/////////// now insert skill
			String sql;
			sql = "delete from EmployeeSkill where Empid="+eid+"";
			stmt.executeUpdate(sql);
			
			for (String value : skillIds) {

				System.out.println("fffff");
				stmt.executeUpdate("insert into EmployeeSkill values('"+eid+"','"+value+"')");
				System.out.println("dddddd");

			}response.sendRedirect("list.jsp");
 
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void create(EmployeeModel employeeModel, String skillIds[],HttpServletRequest request,HttpServletResponse response) {

		Connection connection = null;
		Statement stmt = null;
		ResultSet rs = null;
		String ename= employeeModel.Ename;
		String add= employeeModel.Eaddress;
		String gender= employeeModel.Egender;
		double sal= employeeModel.ESalary;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/sargam","root","root");
			stmt = connection.createStatement();
			// int i= stmt.executeUpdate("insert into
			// Employee(Empid,Ename,Eaddress,Egender,ESalary)
			// values('"+eid+"','"+ename+"','"+add+"','"+gender+"','"+sal+"')"
			// ,Statement.RETURN_GENERATED_KEYS);

			
			
			stmt.executeUpdate("insert into Employee(Ename,Eaddress,Egender,ESalary) values('" + ename + "','" + add
					+ "','" + gender + "','" + sal + "')", Statement.RETURN_GENERATED_KEYS);

			long insertedEmployeeId = 0;
			try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
				if (generatedKeys.next()) {
					insertedEmployeeId = generatedKeys.getLong(1);
				}
			}
			// select * from Employee,EmployeeSkill,SkillMaster where
			// Employee.Empid=EmployeeSkill.Empid and
			// SkillMaster.skillId=EmployeeSkill.Skillid
			/////////// now insert skill

			String sql;
			for (String value : skillIds) {

				// System.out.println(value);
				sql = "insert into EmployeeSkill values (" + insertedEmployeeId + "," + value + ")";
				System.out.println(sql);
				stmt.executeUpdate(sql);
				
			}
			response.sendRedirect("success.jsp");

		} catch (Exception e) {
			e.printStackTrace();
		}
		

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("formservlet : servlet");
		 int eid=Integer.parseInt(request.getParameter("empid"));
		EmployeeModel employeeModel = new EmployeeModel();
		employeeModel.setEmpid(Integer.parseInt(request.getParameter("empid")));
		employeeModel.setEname(request.getParameter("ename"));
		employeeModel.setEaddress(request.getParameter("add"));
		employeeModel.setEgender(request.getParameter("gender"));
		employeeModel.setESalary(Double.parseDouble(request.getParameter("sal")));
		String skillIds[] = request.getParameterValues("skillIds");

		if (employeeModel.getEmpid() == 0) {
			//  - create
			create(employeeModel, skillIds,request,response);
		} else {
			// eidt
			update(employeeModel, skillIds,request,response);
			
		}

	}
}
