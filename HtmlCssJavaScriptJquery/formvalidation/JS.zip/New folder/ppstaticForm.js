var isIPInfoCalled=false;
var isIPInfoCalledSuccess=false;
function fillIPInfo()
{
	if(isIPInfoCalled==false)
	{
	 	isIPInfoCalled=true;
		ajaxCall("https://extreme-ip-lookup.com/json","");
	}	
}
///////////////////////
function GetXmlHttpObject(handler)
{ 
   var objXmlHttp=null;
   if (navigator.userAgent.indexOf("Opera")>=0)
   {
      alert("This example doesn't work in Opera")
      return
   }
   if (navigator.userAgent.indexOf("MSIE")>=0)
   { 
      var strName="Msxml2.XMLHTTP"
      
      if (navigator.appVersion.indexOf("MSIE 5.5")>=0)
      {
         strName="Microsoft.XMLHTTP"
      } 
      try
      { 
         objXmlHttp=new ActiveXObject(strName)
         objXmlHttp.onreadystatechange=handler 
         return objXmlHttp
      } 
      catch(e)
      { 
        alert("Error. Scripting for ActiveX might be disabled") 
         return 
      } 
   } 
   if (navigator.userAgent.indexOf("Mozilla")>=0)
   {
      objXmlHttp=new XMLHttpRequest()
      objXmlHttp.onload=handler
      objXmlHttp.onerror=handler 
      return objXmlHttp
   }
} 
var xmlHttp;
function callbackAjaxCall()
{
	if(xmlHttp.readyState==4)
	{	
		if(xmlHttp.status==200)
		{			
		/*
{
   "businessName" : "",
   "businessWebsite" : "",
   "city" : "Gurgaon",
   "continent" : "Asia",
   "country" : "India",
   "countryCode" : "IN",
   "ipName" : "",
   "ipType" : "Residential",
   "isp" : "Bharti Airtel Limited",
   "lat" : "28.4601",
   "lon" : "77.02635",
   "org" : "Bharti Airtel Limited",
   "query" : "182.74.38.42",
   "region" : "Haryana",
   "status" : "success"
}		
		*/
			//json parse
			
			var resJsonObj;
			resJsonObj=JSON.parse(xmlHttp.responseText);
			//alert(resJsonObj.city);
			document.getElementById("cityAjx").value=resJsonObj.city;
			document.getElementById("regionAjx").value=resJsonObj.region;
			document.getElementById("countryAjx").value=resJsonObj.country;
			isIPInfoCalledSuccess=true;
			
			//alert("resubmit city="+document.getElementById("cityAjx").value)
			//alert("resubmit city="+document.getElementById("regionAjx").value)
			//alert("resubmit city="+document.getElementById("countryAjx").value)
				
			if(reSubmitCase)
			{
				//alert("resubmit ajax");
				var formObj=document.getElementById(submitFormId);
				formObj.submit();
			}
		}
	}
}
function ajaxCall(url,nameValueCollectionObj)
{
	var queryString;
	if( nameValueCollectionObj instanceof NameValueCollection)
	{
		queryString=nameValueCollectionObj.getQueryString();
	}else{
		queryString=nameValueCollectionObj;
	}
	// alert(url+" "+queryString);	
	xmlHttp=GetXmlHttpObject(callbackAjaxCall)
	xmlHttp.open("POST", url , true)
   	xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
	xmlHttp.send(queryString);
}
NameValueCollection = function()
{
	this.name=[];
	this.value=[];
	this.add=function(name,value)
	{
		this.name[this.name.length]=name;
		this.value[this.value.length]=value;
	}	
	this.getQueryString=function()
	{
		var queryString='';
		if(this.name.length==this.value.length)
		{
			for(var n=0;n<this.name.length;n++)
			{
				if(n>0)
				{
					queryString=queryString+"&";
				}
				if(this.name[n]=="action")
				{
					queryString=queryString+this.name[n]+"="+(this.value[n]);
				}else
				{
					queryString=queryString+this.name[n]+"="+encodeURIComponent(this.value[n]);
				}
			}
		}
		return queryString;
	}	
}
///////////////////////
var reSubmitCase=false;
var submitFormId;
function submitPPSForm(formId)
{
	var formObj=document.getElementById(formId);
	if(validateForm())
	{
		updateSourceParameter();
		if(isIPInfoCalledSuccess==false)
		{
			fillIPInfo();
			reSubmitCase=true;
			submitFormId=formId;
		}else
		{
			formObj.submit();
		}
	}
}
function validateForm()
{	
	var inputOk=validateInput();
	var selectOk=validateSelect();
	//alert(inputOk)
	//alert(selectOk)
	//alert("validate=="+((inputOk && selectOk)))
	return (inputOk && selectOk);
	
	
}
function validateInput()
{
	var inputArr=document.getElementsByTagName("input");
	var isValid=true;
	for(var i=0;i<inputArr.length;i++){
		if(isEmpty(inputArr[i].value))
		{	
			//alert("Enter :"+inputArr[i].name)
			inputArr[i].focus();
			inputArr[i].style="background-color:#fae8e8;"
			var scrollTopPix=($(window).scrollTop());			
			if(scrollTopPix>150)
			{
				window.scrollTo($(window).scrollLeft, 150); 
			}
			/*if(inputArr[i].type=="select-one")
			{
				alert("Select Country")
			}*/
			isValid=false;
			break;
		}else
		{
			inputArr[i].style="none"
		}
		if(inputArr[i].name=="inf_field_Email")
		{
			isValid=checkEmail(inputArr[i].value);
			if(isValid==false)
			{
				inputArr[i].focus();
				inputArr[i].style="background-color:#fae8e8;"
			
			}else
			{
				inputArr[i].style="none"
			}
		}
		
		
	}
	return isValid;
}

function checkEmail(email)
{
	var emailStr=email;
	
	if(emailStr=="")
	{
		alert("Please provide E-mail address");
		return false;
	}
	
	var emailPat=/^(.+)@(.+)$/;
	var specialChars="\\(\\)<>@,;:\\\\\\\"\\.\\[\\]";
	var validChars="\[^\\s" + specialChars + "\]";
	var quotedUser="(\"[^\"]*\")";
	var ipDomainPat=/^\[(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\]$/;
	var atom=validChars + '+';
	var word="(" + atom + "|" + quotedUser + ")";
	var userPat=new RegExp("^" + word + "(\\." + word + ")*$");
	var domainPat=new RegExp("^" + atom + "(\\." + atom +")*$");
	var matchArray=emailStr.match(emailPat);
	
	/*if(theForm.email.value==""){
		return true;
	}*/
	if (matchArray==null) {
		alert("Email address seems incorrect (check @ and .'s)");
			//document.updatebidderemail.email.focus();
			//theform.email.focus();
		return false;
	}
	var user=matchArray[1];
	var domain=matchArray[2];
	
	if (user.match(userPat)==null) {
		alert("The username in Email ID doesn't seem to be valid.");
			//document.updatebidderemail.email.focus();
			//theform.email.focus();
		return false;
	}
	
	var IPArray=domain.match(ipDomainPat);
	if (IPArray!=null) {
		  for (var i=1;i<=4;i++) {
			if (IPArray[i]>255) {
				alert("Destination IP address in Email ID is invalid!");
					//document.updatebidderemail.email.focus();
			//theform.email.focus();
			return false;
			}
		}
	}  
	
	
	var domainArray=domain.match(domainPat);
	if (domainArray==null) {
		alert("The domain name in Email ID doesn't seem to be valid.");
			//document.updatebidderemail.email.focus();
			//theform.email.focus();
		return false;
	}
	
	var atomPat=new RegExp(atom,"g");
	var domArr=domain.match(atomPat);
	var len=domArr.length;
	if (domArr[domArr.length-1].length<2 || domArr[domArr.length-1].length>3) {
	   alert("The Email address must end in a three-letter domain, or two letter country.");
				//document.updatebidderemail.email.focus();
			//theform.email.focus();
	   return false;
	}
	if (len<2) {
	   var errStr="This Email address is missing a hostname!";
			//document.updatebidderemail.email.focus();
	   alert(errStr);
			//theform.email.focus();
	   return false;
	  }
	return true;
}
function validateSelect()
{
	var selectArr=document.getElementsByTagName("select");
	var isValid=true;
	for(var i=0;i<selectArr.length;i++){
		//alert(selectArr[i].name)
		selectArr[i].style="background-color:#fae8e8;"
		if(selectArr[i].value=="Country*")
			{	
			//selectArr[i].style="background-color:#fae8e8;"
			document.getElementById("country").style="background-color:#fae8e8;"
				isValid=false;
			}
			
		/*	break;*/
		/*}else
		{
			//tags[i].style="background-color:#ffffff;"
			tags[i].style="none"
		}*/
	}
	return isValid;
}
function isEmpty(data)
{
	if(data=="")
	{
		return true;
	}else
	{
		return false;
	}
}
// /////////////////////Cookies for source parameter////////////////
function getSourceParameter()
{
	var tmp=getCookie("ProcureportSource");
	var tmpURL=getCookie("ProcureportSourceURL");
	if(tmp==null || tmp=='')
	{
		tmp='Procureport';
		
	}	
	return tmp;
}
function updateSourceParameter()
{
	var tmp=getCookie("ProcureportSource");
	var tmpURL=getCookie("ProcureportSourceURL");
	if(tmp==null || tmp=='')
	{
		tmp='Procureport';
		document.getElementById("source").value=tmp;
	}
	else
	{
		document.getElementById("source").value=tmp+' ('+tmpURL+')'
	}

}
function getCookie(c_name)
{
var i,x,y,ARRcookies=document.cookie.split(";");
for (i=0;i<ARRcookies.length;i++)
{
  x=ARRcookies[i].substr(0,ARRcookies[i].indexOf("="));
  y=ARRcookies[i].substr(ARRcookies[i].indexOf("=")+1);
  x=x.replace(/^\s+|\s+$/g,"");
  if (x==c_name)
    {
    return unescape(y);
    }
  }
}

function checkCookie()
{
var tmpurl=document.URL;
if((tmpurl.indexOf("?"))!=-1)
{
var query_string = tmpurl.split("?");
var tmpString=query_string[1].split("=");
var psource=getCookie("ProcureportSource");
var psourceURL=getCookie("ProcureportSourceURL");
	setCookie("ProcureportSourceURL",document.URL,1);
	if (psource!=null && psource!="" && psource!=tmpString[1] && tmpString[1]!=null && (tmpString[0]=='source'||tmpString[0]=='Source'))
  	{
  		setCookie("ProcureportSource",tmpString[1],1);
  	}
  	else if((tmpString[0]=='source'||tmpString[0]=='Source'))
  	{
  		
  		setCookie("ProcureportSource",tmpString[1],1);
  	}
}
}

function setCookie(c_name,value,exdays)
{
var exdate=new Date();
exdate.setDate(exdate.getDate() + exdays);
var c_value=escape(value) + ((exdays==null) ? "" : "; expires="+exdate.toUTCString());
document.cookie=c_name + "=" + c_value;
}


checkCookie();

// /////////////////////End Cookies for source parameter////////////////
