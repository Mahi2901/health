package com.helth.helthcare.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.helth.helthcare.model.ReportModel;

@Repository
public interface ReportRepo extends JpaRepository<ReportModel, Long> 
{
	@Query(value="select * from report where patientid=?1",nativeQuery=true)
	List<ReportModel> findByPatientId(long id);
	
	@Query(value="select * from report where doctorid=?1",nativeQuery=true)
	List<ReportModel> findByDoctortId(long id);
	
}
