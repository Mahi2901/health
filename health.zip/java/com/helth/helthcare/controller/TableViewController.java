package com.helth.helthcare.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.helth.helthcare.model.DoctorModel;
import com.helth.helthcare.model.HospitalModel;
import com.helth.helthcare.repository.ArticalRepo;
import com.helth.helthcare.repository.BookingRepo;
import com.helth.helthcare.repository.DoctorRepo;
import com.helth.helthcare.repository.HospitalRepo;
import com.helth.helthcare.repository.PatientRepo;
import com.helth.helthcare.repository.ReceptionRepo;
import com.helth.helthcare.util.JasperExporter;

@Controller
@RequestMapping("/Admin")
public class TableViewController 
{
	
	/*
	 * @Autowired BookAppointRepo bookAppointRepo;
	 */
	HashMap jasperParameter;
	@Autowired
	PatientRepo patientRepo;
	
	@Autowired
	HospitalRepo hospitalRepo;
	
	@Autowired
	DoctorRepo doctorRepo;
	
	@Autowired
	ReceptionRepo recaptionRepo;
	
	@Autowired
	ArticalRepo articalRepo;
	

	@Autowired
	BookingRepo bookingRepo;
	
	
	@RequestMapping("/hospitalData")
	@ResponseBody
	public List<HospitalModel> listHospital() 
	{
		return hospitalRepo.findAll();
	}

	@RequestMapping("/doctorData/{hospitalid}")
	@ResponseBody
	public List<DoctorModel> listDoctor(@PathVariable long hospitalid) 
	{
		return doctorRepo.findDoctor(hospitalid);
	}
	
	@RequestMapping("/DoctorTable")
	public ModelAndView doctorTable() 
	{
		ModelAndView mv = new ModelAndView("/Admin/DoctorTable");
		mv.addObject("list", doctorRepo.findAll());
		return mv;
	}
	
	@RequestMapping("/HospitalTable")
	public ModelAndView hospitalTable() 
	{
		ModelAndView mv = new ModelAndView("/Admin/HospitalTable");
		mv.addObject("list", recaptionRepo.findAll());
		return mv;
	}
	
	@RequestMapping("/AppointmentTable")
	public ModelAndView appointmentTable() 
	{
		ModelAndView mv = new ModelAndView("/Admin/AppointmentTable");
		mv.addObject("list", bookingRepo.findAll());
		return mv;
	}
	
	@RequestMapping("/PatientTable")
	public ModelAndView patientTable() 
	{
		ModelAndView mv = new ModelAndView("/Admin/PatientTable");
		mv.addObject("list", patientRepo.findAll());
		return mv;
	}
	
	@RequestMapping("/getPatientCount")
	@ResponseBody
	public long getPatientCount() 
	{

		return patientRepo.count();
	}
	
	@RequestMapping("/getDoctorCount")
	@ResponseBody
	public long getDoctorCount() 
	{

		return doctorRepo.count();
	}
	@RequestMapping("/getHospitalCount")
	@ResponseBody
	public long getHospitalCount() 
	{

		return hospitalRepo.count();
	}
	
	@RequestMapping("/getReceptionCount")
	@ResponseBody
	public long getReceptionCount() 
	{

		return recaptionRepo.count();
	}
	
	@RequestMapping("/getAppointmentCount")
	@ResponseBody
	public long getAppointmentCount() 
	{

		return bookingRepo.count();
	}
	@RequestMapping("/getArticleCount")
	@ResponseBody
	public long getArticleCount() 
	{

		return articalRepo.count();
	}
	



}
