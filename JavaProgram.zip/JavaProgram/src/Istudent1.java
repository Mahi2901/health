
public class Istudent1 extends Iperson1
{
	private int rollNo;
	public void setRollNo(int r)
	{
		rollNo = r;
	}
	public int getrollNo()
	{
		return (rollNo);
	}
}
