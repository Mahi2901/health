package com.helth.helthcare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelthcareApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelthcareApplication.class, args);
	}

}
