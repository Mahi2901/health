package com.helth.helthcare.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.helth.helthcare.model.PatientModel;
import com.helth.helthcare.model.Role;
import com.helth.helthcare.model.User;
import com.helth.helthcare.repository.DoctorRepo;
import com.helth.helthcare.repository.PatientRepo;
import com.helth.helthcare.repository.ReceptionRepo;
import com.helth.helthcare.repository.RoleRepo;
import com.helth.helthcare.repository.UserRepo;
import com.helth.helthcare.service.ArticalService;
import com.helth.helthcare.service.PatientServiceImp;

@Controller
@RequestMapping("/")
public class PatienthomeController 
{
	BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
	private static String UPLOADED_FOLDER = "E://workspace//helthcare//src//main//resources//static//Profiles//";
	
	@Autowired
	ReceptionRepo recaptionRepo;
	
	@Autowired
	PatientRepo patientRepo;
	
	@Autowired
	DoctorRepo doctorRepo;
	
//	@Autowired
//	BookAppointRepo bookAppointRepo;
	
	@Autowired
	PatientServiceImp patientService;
	
	@Autowired
	ArticalService articalService;
	
	@Autowired
	UserRepo userRepo;
	
	@Autowired
	RoleRepo roleRepo;
	
	@RequestMapping(value = { "", "/", "index" })
	public String he() 
	{
		return "Patienthome/index";
	}
	
	@RequestMapping("/{page}")
	public String page(@PathVariable String page) 
	{
		return "Patienthome/"+page;
	}
	
	@RequestMapping(value= {"/403"})
	public String errors() 
	{
		
		return "403";
		
	}
	
	@RequestMapping(value = "/Reset-Password", method = RequestMethod.GET)
	public String getResetPassword(@RequestParam("token") String resetToken,Model m) 
	{
		
			User user = userRepo.findByResetToken(resetToken);
			if(user!=null) {
			
			m.addAttribute("email", user.getEmail());
			return "Patienthome/Reset-Password";
			}else {
				
				   return "redirect:/403";
			   }
		
		
	}
	
	@RequestMapping(value = "/Reset-Password", method = RequestMethod.POST)
	public String gsetResetPassword(@RequestParam("email") String email,@RequestParam("password") String password,Model m) 
	{
		
			User user = userRepo.findByEmail(email);
			user.setPassword(passwordEncoder.encode(password));
			user.setResetToken(UUID.randomUUID().toString());
			userRepo.save(user);
			m.addAttribute("message", "Password succesfully updated");
			return "redirect:/index";
		}
	
	
	@RequestMapping("/savepatient")
	public String savepatient(@ModelAttribute() PatientModel patient,@RequestParam("password") String password,@RequestParam("email") String email,  RedirectAttributes redirectAttributes,User user) 
	{	
		Role r = roleRepo.findById((long) 1).orElse(null);
		
		Set<Role> roles = new HashSet<Role>();
		roles.add(r);
		
		
		user.setEmail(email);
		user.setPassword(passwordEncoder.encode(password));
		user.setRoles(roles);
		user.setResetToken(UUID.randomUUID().toString());
		
		patient.setImage("admin.jpg");
		patientService.save(patient);
		user.setPatientModel(patient);
		
		userRepo.save(user);
		redirectAttributes.addFlashAttribute("success", "Registration Successfully");
		return "redirect:/PatientRegistration";
	}
	
	@RequestMapping("/updatepatient")
	public String updatepatient(@ModelAttribute() PatientModel patient,@RequestParam("file") MultipartFile file,@RequestParam("email") String email, RedirectAttributes redirectAttributes) 
	{	
		if (file.isEmpty()) {
            redirectAttributes.addFlashAttribute("message", "Please select a file to upload");
            return "redirect:uploadStatus";
        }

        try {

            // Get the file and save it somewhere
            byte[] bytes = file.getBytes();
            Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
            Files.write(path, bytes);

            redirectAttributes.addFlashAttribute("message",
                    "You successfully uploaded '" + file.getOriginalFilename() + "'");

        } catch (IOException e) {
            e.printStackTrace();
        }
        String filename = file.getOriginalFilename();
        patient.setImage(filename);
        
		patientService.save(patient);
		User u = userRepo.findById(patient.getPatientid()).orElse(null);
		u.setEmail(email);
		userRepo.save(u);
		
		redirectAttributes.addFlashAttribute("success", "Registration Successfully");
		return "redirect:/Patientdash/index";
	}
	
	

}
