package com.helth.helthcare.model;

import javax.persistence.Entity;


import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="report")
public class ReportModel 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long reportid;
	private String reportname;
	private String description;
	private String date;
	
	
	
	public String getDate() {
		return date;
	}


	public void setDate(String date) {
		this.date = date;
	}


	@ManyToOne
	@JoinColumn(name = "patientid")
	private PatientModel patientModel;

	
	@ManyToOne
	@JoinColumn(name = "hospitalid")
	private HospitalModel hospitalModel;

	
	@ManyToOne
	@JoinColumn(name = "doctorid")
	private DoctorModel doctorModel;


	public long getReportid() {
		return reportid;
	}


	public void setReportid(long reportid) {
		this.reportid = reportid;
	}


	public String getReportname() {
		return reportname;
	}


	public void setReportname(String reportname) {
		this.reportname = reportname;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public PatientModel getPatientModel() {
		return patientModel;
	}


	public void setPatientModel(PatientModel patientModel) {
		this.patientModel = patientModel;
	}


	public HospitalModel getHospitalModel() {
		return hospitalModel;
	}


	public void setHospitalModel(HospitalModel hospitalModel) {
		this.hospitalModel = hospitalModel;
	}


	public DoctorModel getDoctorModel() {
		return doctorModel;
	}


	public void setDoctorModel(DoctorModel doctorModel) {
		this.doctorModel = doctorModel;
	}

	
	
	
}
