package com.action;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.connection.DBConnection;
import com.model.EmployeeModel;
import com.model.SkillModel;

@WebServlet("/EditAction")
public class EditAction extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public EditAction() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("==================");
		System.out.println(request.getParameter("id"));
		System.out.println("==========");

		Connection connection = null;
		Statement stmt = null;
		ResultSet rs = null;
		String empId_st = request.getParameter("id");
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/sargam","root","root");
			stmt = connection.createStatement();
			System.out.println("1");

			String sql = "Select *  from  Employee where Empid =" + empId_st;
			System.out.println("2");
			rs = stmt.executeQuery(sql);

			// PreparedStatement edit =connection.prepareStatement(sql);
			// rs = edit.executeQuery();
			if (rs.next()) {
				EmployeeModel employeeVO = new EmployeeModel();
				employeeVO.setEmpid(rs.getInt("Empid"));
				employeeVO.setEname(rs.getString("Ename"));
				employeeVO.setEaddress(rs.getString("Eaddress"));
				employeeVO.setEgender(rs.getString("Egender"));
				employeeVO.setESalary(rs.getInt("Esalary"));

				// Empid Ename Eaddress Egender ESalary
				System.out.println(rs.getInt("Empid"));
				System.out.println(rs.getString("Ename"));
				System.out.println(rs.getString("Eaddress"));
				System.out.println(rs.getString("Egender"));
				System.out.println(rs.getInt("ESalary"));

				System.out.println("employeeVO===" + employeeVO);
				request.setAttribute("employeeModel", employeeVO);
			}

			//////////// Prepare Skill From SKill Master////////////////
			SkillModel skillMaster;
			ArrayList<SkillModel> skillMasterArrayList = new ArrayList<SkillModel>();
			sql = "select DISTINCT Skillmaster.skillId,Skillmaster.name,Empid from Skillmaster left join EmployeeSkill on (Skillmaster.skillId=EmployeeSkill.skillId and EmployeeSkill.Empid="
					+ empId_st + ")  ";
			rs = stmt.executeQuery(sql);
			int tmpEid;
			while (rs.next()) {
				skillMaster = new SkillModel();
				skillMaster.setSkillId(rs.getInt("skillId"));
				skillMaster.setName(rs.getString("name"));
				tmpEid = rs.getInt("Empid");
				
				if (tmpEid > 0) {
					skillMaster.setSelected(true);
				} else {
					skillMaster.setSelected(false);
				}

				skillMasterArrayList.add(skillMaster);

				System.out.println(skillMaster.getName());
				System.out.println(skillMaster.getSkillId());

			}
			System.out.println(skillMasterArrayList);
			request.setAttribute("skillModelArrayList", skillMasterArrayList);
			
							
			////////////// forward action/////////////////////
			
			
			
			RequestDispatcher rd = request.getRequestDispatcher("Employee.jsp");
			
			rd.forward(request, response);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

}
