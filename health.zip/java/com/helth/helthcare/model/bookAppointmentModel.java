/*
 package com.helth.helthcare.model;
 

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="appointment")
public class bookAppointmentModel {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name="Id")
private long bookingid;
private String name;
private String phone;
private String email;
private String dob;

@ManyToOne
@JoinColumn(name="hospitalid")
private HospitalModel hospitalModel;
private String disease;

@ManyToOne
@JoinColumn(name="doctorid")
private DoctorModel doctorModel;

private String appointmentDate;
private String address;


public long getBookingid() {
	return bookingid;
}
public void setBookingid(long bookingid) {
	this.bookingid = bookingid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public HospitalModel getHospitalModel() {
	return hospitalModel;
}
public void setHospitalModel(HospitalModel hospitalModel) {
	this.hospitalModel = hospitalModel;
}
public String getDisease() {
	return disease;
}
public void setDisease(String disease) {
	this.disease = disease;
}
public DoctorModel getDoctorModel() {
	return doctorModel;
}
public void setDoctorModel(DoctorModel doctorModel) {
	this.doctorModel = doctorModel;
}
public String getAppointmentDate() {
	return appointmentDate;
}
public void setAppointmentDate(String appointmentDate) {
	this.appointmentDate = appointmentDate;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}






}
*/
