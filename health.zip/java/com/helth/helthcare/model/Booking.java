package com.helth.helthcare.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "bookappointment")
public class Booking 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long bookingid;

	
	@ManyToOne
	@JoinColumn(name = "patientid")
	private PatientModel patientModel;

	
	@ManyToOne
	@JoinColumn(name = "hospitalid")
	private HospitalModel hospitalModel;

	
	@ManyToOne
	@JoinColumn(name = "doctorid")
	private DoctorModel doctorModel;

	
	@ManyToOne
	@JoinColumn(name = "departmentid")
	private DepartmentModel departmentModel;

	private String date;
	private String paymentstatus;

	public long getBookingid() {
		return bookingid;
	}

	public void setBookingid(long bookingid) {
		this.bookingid = bookingid;
	}

	public PatientModel getPatientModel() {
		return patientModel;
	}

	public void setPatientModel(PatientModel patientModel) {
		this.patientModel = patientModel;
	}

	public HospitalModel getHospitalModel() {
		return hospitalModel;
	}

	public void setHospitalModel(HospitalModel hospitalModel) {
		this.hospitalModel = hospitalModel;
	}

	public DoctorModel getDoctorModel() {
		return doctorModel;
	}

	public void setDoctorModel(DoctorModel doctorModel) {
		this.doctorModel = doctorModel;
	}

	public DepartmentModel getDepartmentModel() {
		return departmentModel;
	}

	public void setDepartmentModel(DepartmentModel departmentModel) {
		this.departmentModel = departmentModel;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getPaymentstatus() {
		return paymentstatus;
	}

	public void setPaymentstatus(String paymentstatus) {
		this.paymentstatus = paymentstatus;
	}
	
	

}
