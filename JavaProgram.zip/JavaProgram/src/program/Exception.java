package program;

public class Exception {
    public static void main(String args[]) throws ArithmeticException{  
    
    //int a=10;
    String s1=null;
    System.out.println("Mahi");
     // int c = a/0;
     //    System.out.println(c);
    System.out.println(s1.length());
        System.out.println("Chhatraliya");
    }
}
