package com.helth.helthcare.service;

import java.util.List;

import com.helth.helthcare.model.ArticalModel;

public interface ArticalService 
{
	public ArticalModel save(ArticalModel artical);
	public List<ArticalModel> findByType(String type);
	public ArticalModel findById(long id);
	public List<ArticalModel> findByDoctorId(long id);
}
