
public class Iperson1 {
    private  int age;
    private String name;
    public void setAge(int a){
        age=a;
    }
    public void setName(String n){
        name=n;
    }
    public int getAge(){
        return(age); 
    }
    public String getName(){
        return(name); 
    }
}
