package com.helth.helthcare.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.helth.helthcare.model.DoctorModel;

@Repository
public interface DoctorRepo extends JpaRepository<DoctorModel, Long>  
{
	@Query(value="select * from doctor where hospitalid=?1",nativeQuery=true)
	List<DoctorModel> findDoctor(long id);
	
	@Query(value="select * from doctor where departmentid=?1",nativeQuery=true)
	List<DoctorModel> getDoctor(long id);
	
	@Query(value="select * from doctor where email=?1 and password=?2",nativeQuery=true)
	DoctorModel getDoctor(String uname, String pass);
	
	@Query(value="select count(*) from doctor where hospitalid=1",nativeQuery=true)
	long getDoctorCount(long id);
	
	@Query(value="select * from doctor where doctorid=1",nativeQuery=true)
	DoctorModel getDoctorDetail(long id);
	
	/* DoctorModel findByEmail(String email); */
	/* DoctorModel findByResetToken(String resetToken); */
	
	@Query(value="update doctor set password=?1 where doctorid=?2",nativeQuery=true)
	public void updatepassword(String password,long id);

}
