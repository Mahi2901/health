package com.helth.helthcare.controller;

import java.io.IOException;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.helth.helthcare.model.AdminModel;
import com.helth.helthcare.model.DoctorModel;
import com.helth.helthcare.model.ReceptionModel;
import com.helth.helthcare.model.Role;
import com.helth.helthcare.model.User;
import com.helth.helthcare.repository.AdminRepo;
import com.helth.helthcare.repository.DoctorRepo;
import com.helth.helthcare.repository.HospitalRepo;
import com.helth.helthcare.repository.PatientRepo;
import com.helth.helthcare.repository.ReceptionRepo;
import com.helth.helthcare.repository.RoleRepo;
import com.helth.helthcare.repository.UserRepo;
import com.helth.helthcare.service.ReceptionService;


@Controller
@RequestMapping("/Admin")
public class Admin 
{
	BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

	private static String UPLOADED_FOLDER = "E://workspace//helthcare//src//main//resources//static//Profiles//";
	
	@Autowired
	private JavaMailSender sender;
	
	
	@Autowired
	PatientRepo patientRepo;
	
	@Autowired
	HospitalRepo hospitalRepo;
	
	@Autowired
	AdminRepo adminRepo;
	
	@Autowired
	DoctorRepo doctorRepo;
	
	
	@Autowired
	ReceptionRepo recaptionRepo;
	
	@Autowired
	UserRepo userRepo;
	
	@Autowired
	RoleRepo roleRepo;
	
	@Autowired
	ReceptionService receptionService;
	
	
	@RequestMapping(value = { "", "/", "index" })
	public String index1() {
		return "Admin/index";
	}

	@RequestMapping("/{page}")
	public String page1(@PathVariable String page) {
		return "Admin/"+page;
	}
	
//	@Autowired
//	HospitalService hospitalservice;
	
	@Autowired
	ReceptionService recaptionService;
	
	
	
	@RequestMapping("/savehospital")
	public String ins(@ModelAttribute ReceptionModel reception,@RequestParam("password") String password,@RequestParam("email") String email,User user) 
	{
		Role r = roleRepo.findById((long) 3).orElse(null);
		
		Set<Role> roles = new HashSet<Role>();
		roles.add(r);
		
		
		
		user.setEmail(email);
		user.setPassword(passwordEncoder.encode(password));
		user.setRoles(roles);
		user.setResetToken(UUID.randomUUID().toString());
		
		reception.setImage("admin.jpg");
		recaptionService.save(reception);
		user.setReceptionModel(reception);
		
		userRepo.save(user);
		
		   MimeMessage message = sender.createMimeMessage();
		   MimeMessageHelper helper = new MimeMessageHelper(message);
		   try {
				helper.setTo(user.getEmail());
				helper.setText("Your User Name is : "+ email +" And Password is="+password);
				helper.setSubject("Mail For security info");
			} catch (MessagingException e) {
				e.printStackTrace();
				return "Error while sending mail ..";
			}
			sender.send(message);
		return "/Admin/index";
	}
	
	@RequestMapping("/changepassword")
	public String changePassword(@RequestParam("id") long id,@RequestParam("password") String password,Model model) 
	{
		User user = userRepo.findById(id).orElse(null);
		
		user.setPassword(passwordEncoder.encode(password));
		userRepo.save(user);
		model.addAttribute("message", "Password Successfully Updated");
		
		return "Admin/Changepassword";
	}
	
	
	@RequestMapping("/uploading")
	public String imageUpload(@RequestParam("id") long id, @RequestParam("file") MultipartFile file) 
	{
		AdminModel admin = adminRepo.findById(id).orElse(null);
		System.out.println(id);
		if (file.isEmpty()) {
            
            return "redirect:/Admin/Imageupload";
        }

        try {

            // Get the file and save it somewhere
            byte[] bytes = file.getBytes();
            Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
            Files.write(path, bytes);

        } catch (IOException e) {
            e.printStackTrace();
        }
        String image = file.getOriginalFilename();
        System.out.println(image);
		admin.setImage(image);
		adminRepo.save(admin);
		
		return "redirect:/Admin/index";
	}
	
	@RequestMapping("/saveDoctor")
	public String saveDoctor(@ModelAttribute DoctorModel d1) 
	{
		
		doctorRepo.save(d1);
		return "redirect:/Admin/index";
	}
	
	@RequestMapping("/AdminRecord/{id}")
	@ResponseBody
	public User findAdmin(@PathVariable long id) 
	{
		return userRepo.findById(id).orElse(null);
	}
	
	@RequestMapping("/DeleteHospital/{id}")
	public String deleteHospital(@PathVariable long id) 
	{
		recaptionRepo.deleteById(id);
	  return "redirect:/Admin/HospitalTable";
	}
	
	
	
	
	
}
