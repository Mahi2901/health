package com.helth.helthcare.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.helth.helthcare.model.AdminModel;

@Repository
public interface AdminRepo extends JpaRepository<AdminModel, Long> 
{
	/*
	 * @Query(value="select * from admin where name=?1 and password=?2",nativeQuery=
	 * true) AdminModel getAdmin(String uname, String pass);
	 */
	
	/*
	  @Query(value="update admin set password=?1 where id=?1",nativeQuery=true)
	  void changePass(String password,long id);
	 */
	 
	
}
