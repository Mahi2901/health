package com.helth.helthcare.service;

import com.helth.helthcare.model.HospitalModel;

public interface HospitalService 
{
	public HospitalModel save(HospitalModel h);
}
