package com.helth.helthcare.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.helth.helthcare.model.ArticalModel;
import com.helth.helthcare.repository.ArticalRepo;


@Service
@Transactional
public class ArticalServiceImp implements ArticalService {
	
	@Autowired
	ArticalRepo articalRepo;
	

	@Override
	public ArticalModel save(ArticalModel artical) {
		// TODO Auto-generated method stub
		return articalRepo.save(artical);
	}

	@Override
	public List<ArticalModel> findByType(String type) {
		// TODO Auto-generated method stub
		return articalRepo.findByArticaltype(type);
	}

	@Override
	public ArticalModel findById(long id) {
		// TODO Auto-generated method stub
		return articalRepo.findById(id).orElse(null);
	}

	@Override
	public List<ArticalModel> findByDoctorId(long id) {
		// TODO Auto-generated method stub
		return articalRepo.findByDoctorid(id);
	}

}
