package com.helth.helthcare.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.helth.helthcare.model.PatientModel;
import com.helth.helthcare.repository.PatientRepo;

@Service
@Transactional
public class PatientServiceImp implements PatientService 
{
	@Autowired
	PatientRepo patientRepo;

	@Override
	public PatientModel save(PatientModel patient) {
		// TODO Auto-generated method stub
		return patientRepo.save(patient);
	}

	@Override
	public PatientModel findOne(long id) {
		// TODO Auto-generated method stub
		return patientRepo.findById(id).orElse(null);
	}

	@Override
	public void delete(PatientModel patient) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public PatientModel updatePatient(MultipartFile file, long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updatepassword(String password, long id) {
		// TODO Auto-generated method stub
		
	}

	
	

}
