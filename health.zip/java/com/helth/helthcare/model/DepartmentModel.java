package com.helth.helthcare.model;

import javax.persistence.Entity;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="department")
public class DepartmentModel 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long departmentid;
	private String departmentname;
	
	@ManyToOne
	@JoinColumn(name="hospitalid")
	private HospitalModel hospitalModel;

	

	public long getDepartmentid() {
		return departmentid;
	}

	public void setDepartmentid(long departmentid) {
		this.departmentid = departmentid;
	}

	public String getDepartmentname() {
		return departmentname;
	}

	public void setDepartmentname(String departmentname) {
		this.departmentname = departmentname;
	}

	public HospitalModel getHospitalModel() {
		return hospitalModel;
	}

	public void setHospitalModel(HospitalModel hospitalModel) {
		this.hospitalModel = hospitalModel;
	}
	
		
}
