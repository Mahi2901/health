package com.helth.helthcare.service;

import com.helth.helthcare.model.ReceptionModel;

public interface ReceptionService 
{
	public ReceptionModel save(ReceptionModel r);
	public ReceptionModel findOne(long id);
	public void delete(long id);
}
