package Concept;

import java.util.*;

public class PackageClass 
{
    public static void main(String[] args) 
    {
        String s = "Hello";
        ArrayList l1 = new ArrayList();
        l1.toString();  //AbstrsctollectionClass
        //  toString is method of String class
    }
    
}
