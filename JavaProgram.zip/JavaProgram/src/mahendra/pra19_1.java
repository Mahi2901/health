
package mahendra;

public class pra19_1
{
	public StringBuffer rs(String s)
	{
		StringBuffer sb = new StringBuffer(s);
		sb = sb.reverse();
		return sb;
	}
}
