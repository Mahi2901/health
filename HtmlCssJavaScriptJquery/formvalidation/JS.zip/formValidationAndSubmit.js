var responseFunction;

function GetXmlHttpObject(handler)
{ 
   var objXmlHttp=null;
   if (navigator.userAgent.indexOf("Opera")>=0)
   {
      alert("This example doesn't work in Opera")
      return
   }
   if (navigator.userAgent.indexOf("MSIE")>=0)
   { 
      var strName="Msxml2.XMLHTTP"
      
      if (navigator.appVersion.indexOf("MSIE 5.5")>=0)
      {
         strName="Microsoft.XMLHTTP"
      } 
      try
      { 
         objXmlHttp=new ActiveXObject(strName)
         objXmlHttp.onreadystatechange=handler 
         return objXmlHttp
      } 
      catch(e)
      { 
        alert("Error. Scripting for ActiveX might be disabled") 
         return 
      } 
   } 
   if (navigator.userAgent.indexOf("Mozilla")>=0)
   {
      objXmlHttp=new XMLHttpRequest()
      objXmlHttp.onload=handler
      objXmlHttp.onerror=handler 
      return objXmlHttp
   }
} 

var xmlHttp;
function callbackAjaxCall()
{
	if(xmlHttp.readyState==4)
	{	
		if(xmlHttp.status==200)
		{				
			//json parse
			var resJsonObj;
			resJsonObj=JSON.parse(xmlHttp.responseText)
			submitFinlaForm(resJsonObj);
		}
	}
}
function ajaxCall(url,nameValueCollectionObj)
{
	var queryString;
	if( nameValueCollectionObj instanceof NameValueCollection)
	{
		queryString=nameValueCollectionObj.getQueryString();
	}else{
		queryString=nameValueCollectionObj;
	}
	// alert(url+" "+queryString);	
	xmlHttp=GetXmlHttpObject(callbackAjaxCall)
	xmlHttp.open("POST", url , true)
   	xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
	xmlHttp.send(queryString);
	// alert('start animation')
	// var progressBar= new DHTML_ProgressBar();
	// progressBar._createDiv();
}
var passFormObjectAjax;
function submitFinlaForm(resJsonObj)
{
	if(passFormObjectAjax.action.indexOf("?")>0)
	{
		passFormObjectAjax.action=passFormObjectAjax.action+"&cityAjx="+resJsonObj.city;	
	}else
	{
		passFormObjectAjax.action=passFormObjectAjax.action+"?cityAjx="+resJsonObj.city;	
	}
	//alert("passFormObjectAjax.action="+passFormObjectAjax.action);
	passFormObjectAjax.submit();
}


///////////////////////////////
//nowSubmit work
function getIPAndCityAndSubmit()
{
	//ajaxCall("http://ip-api.com/json","");	
	//ajaxCall("https://ip-api.io/json","");	
	//ajaxCall("https://ipapi.co/json","");	
	ajaxCall("https://extreme-ip-lookup.com/json","");


}
////////////////
function validateCloudReverseAuction(formObj)
{
	if(
	validateField("inf_field_FirstName",1,"Please provide First Name")
	&&
	validateField("inf_field_Telephone",1,"Please provide Phone")
	&&
	validateField("inf_field_Email",2,"Please provide email address")
	)
	{
		passFormObjectAjax=formObj;
		getIPAndCityAndSubmit();
		//alert(passFormObjectAjax.action)
		return true;
		//return false;
	}
	else
	{
		return false;
	}
}
function validateContactUs()
{
	updateSourceParameter();
	if(
	validateField("inf_field_FirstName",1,"Please provide First Name")
	&&
	validateField("inf_field_LastName",1,"Please provide Last Name")
	&&
	validateField("inf_field_Email",2,"Please provide email address")
	&&
	validateField("inf_field_Phone1",1,"Please provide Phone")
	)
	{
		return true;
	}else
	{
		return false;
	}
}


function validateWhitePaper()
{
	updateSourceParameter();
	if(
	validateField("inf_field_FirstName",1,"Please provide First Name")
	&&
	validateField("inf_field_LastName",1,"Please provide Last Name")
	&&
	validateField("inf_field_Email",2,"Please provide email address")
	&&
	validateField("inf_field_Company",1,"Please provide CompanyName")
	&&
	validateField("inf_field_Phone1",1,"Please provide Phone")
	
	)
	{
		return true;
	}else
	{
		return false;
	}
}



function validateField(id, validationType, message) {
	var returnVal = true;
	var data = document.getElementById(id).value;
	if (validationType == 1)// empty
	{
		if (data == null || data == "") {
			alert(message);
			returnVal = false;
		}
	} else if (validationType == 2)// email
	{
		returnVal = checkEmail(data);
	}
	try{
		if(returnVal==false){
		document.getElementById(id).focus();
		/*
		//added to scroll
		var scrollTopPix=($(window).scrollTop());			
		if(scrollTopPix>150)
		{
			window.scrollTo($(window).scrollLeft, 150); 
		}
		*/
	}
	}catch(err)
	{
	}
	return returnVal;
}
// //////////////////
function checkEmail(email) {
	var emailStr = email;

	if (emailStr == "") {
		alert("Please provide E-mail address");
		return false;
	}

	var emailPat = /^(.+)@(.+)$/;
	var specialChars = "\\(\\)<>@,;:\\\\\\\"\\.\\[\\]";
	var validChars = "\[^\\s" + specialChars + "\]";
	var quotedUser = "(\"[^\"]*\")";
	var ipDomainPat = /^\[(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\]$/;
	var atom = validChars + '+';
	var word = "(" + atom + "|" + quotedUser + ")";
	var userPat = new RegExp("^" + word + "(\\." + word + ")*$");
	var domainPat = new RegExp("^" + atom + "(\\." + atom + ")*$");
	var matchArray = emailStr.match(emailPat);

	/*
	 * if(theForm.email.value==""){ return true; }
	 */
	if (matchArray == null) {
		alert("Email address seems incorrect (check @ and .'s)");
		// document.updatebidderemail.email.focus();
		// theform.email.focus();
		return false;
	}
	var user = matchArray[1];
	var domain = matchArray[2];

	if (user.match(userPat) == null) {
		alert("The username in Email ID doesn't seem to be valid.");
		// document.updatebidderemail.email.focus();
		// theform.email.focus();
		return false;
	}

	var IPArray = domain.match(ipDomainPat);
	if (IPArray != null) {
		for (var i = 1; i <= 4; i++) {
			if (IPArray[i] > 255) {
				alert("Destination IP address in Email ID is invalid!");
				// document.updatebidderemail.email.focus();
				// theform.email.focus();
				return false;
			}
		}
	}

	var domainArray = domain.match(domainPat);
	if (domainArray == null) {
		alert("The domain name in Email ID doesn't seem to be valid.");
		// document.updatebidderemail.email.focus();
		// theform.email.focus();
		return false;
	}

	var atomPat = new RegExp(atom, "g");
	var domArr = domain.match(atomPat);
	var len = domArr.length;
	if (domArr[domArr.length - 1].length < 2 || domArr[domArr.length - 1].length > 3) {
		alert("The Email address must end in a three-letter domain, or two letter country.");
		// document.updatebidderemail.email.focus();
		// theform.email.focus();
		return false;
	}
	if (len < 2) {
		var errStr = "This Email address is missing a hostname!";
		// document.updatebidderemail.email.focus();
		alert(errStr);
		// theform.email.focus();
		return false;
	}
	return true;
}
function isNumberKey(evt) {
	var charCode = (evt.which) ? evt.which : evt.keyCode;
	if (charCode > 31 && (charCode < 48 || charCode > 57)) {
		return false;
	}
	return true;
}


/////////////
NameValueCollection = function()
{
	this.name=[];
	this.value=[];
	this.add=function(name,value)
	{
		this.name[this.name.length]=name;
		this.value[this.value.length]=value;
	}	
	this.getQueryString=function()
	{
		var queryString='';
		if(this.name.length==this.value.length)
		{
			for(var n=0;n<this.name.length;n++)
			{
				if(n>0)
				{
					queryString=queryString+"&";
				}
				if(this.name[n]=="action")
				{
					queryString=queryString+this.name[n]+"="+(this.value[n]);
				}else
				{
					queryString=queryString+this.name[n]+"="+encodeURIComponent(this.value[n]);
				}
			}
		}
		return queryString;
	}	
}
