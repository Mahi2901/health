package com.helth.helthcare.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "artical")
public class ArticalModel 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long articalid;
	private String articaltype;
	private String artical;
	private String image;
	private String date;
	
	
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "doctorid")
	private DoctorModel doctorModel;

	public long getArticalid() {
		return articalid;
	}

	public void setArticalid(long articalid) {
		this.articalid = articalid;
	}

	public String getArtical() {
		return artical;
	}

	public void setArtical(String artical) {
		this.artical = artical;
	}
	

	public String getArticaltype() {
		return articaltype;
	}

	public void setArticaltype(String articaltype) {
		this.articaltype = articaltype;
	}

	public DoctorModel getDoctorModel() {
		return doctorModel;
	}

	public void setDoctorModel(DoctorModel doctorModel) {
		this.doctorModel = doctorModel;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
	
	

	

}
