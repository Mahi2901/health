package Concept;

public class ForLoopExample 
{
	public static void main(String[] args) 
	{
		
		
/*
 		 for (int i = 0, String = "GFG"; i < 2; i++)           //Initialization part of the for loop will be executed only once in the for loop life cycle. Here we can declare any number of variables but should be of same type. By mistake if we are trying to declare different data types variables then we will get compile time error saying error: incompatible types: String cannot be converted to int.
 
	            System.out.println("HELLO GEEKS");
		
		for (int i = 0; i < 1; System.out.println("WELCOME")) 	// infinity
			System.out.println("GEEKS");

		int i = 0;
		for (System.out.println("HI"); i < 1; i++)		// the initialization section we can take any valid java statement including System.out.println(). In the for loop initialization section is executed only once that�s why here it will print first HI and after that HELLO GEEKS
			System.out.println("HELLO GEEKS");

		for (int i = 0;; i++)
			System.out.println("HELLO GEEKS");		// In the conditional check we can take any valid java statement but should be of type Boolean. If we did not give any statement then it always returns true.

		for (;;)
			System.out.println("HELLO GEEKS"); 		// infinity
*/
	}
}
