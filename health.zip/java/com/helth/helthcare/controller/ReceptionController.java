package com.helth.helthcare.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.helth.helthcare.model.Booking;
import com.helth.helthcare.model.DepartmentModel;
import com.helth.helthcare.model.DoctorModel;
import com.helth.helthcare.model.ReceptionModel;
import com.helth.helthcare.model.Role;
import com.helth.helthcare.model.User;
import com.helth.helthcare.repository.BookingRepo;
import com.helth.helthcare.repository.DepartmentRepo;
import com.helth.helthcare.repository.DoctorRepo;
import com.helth.helthcare.repository.HospitalRepo;
import com.helth.helthcare.repository.PatientRepo;
import com.helth.helthcare.repository.ReceptionRepo;
import com.helth.helthcare.repository.RoleRepo;
import com.helth.helthcare.repository.UserRepo;
import com.helth.helthcare.service.PatientService;
import com.helth.helthcare.service.ReceptionService;
import com.helth.helthcare.service.ReportService;

@Controller
@RequestMapping("/Reception")
public class ReceptionController 
{
	BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
	private static String UPLOADED_FOLDER = "E://workspace//helthcare//src//main//resources//static//Profiles//";

//	@Autowired
//	BookAppointRepo bookAppointRepo;
//	
	@Autowired
	private JavaMailSender sender;
	@Autowired
	ReportService reportService;
	
	@Autowired
	PatientRepo patientRepo;
	@Autowired
	
	PatientService patientService;
	@Autowired
	BookingRepo bookingRepo;
	
	@Autowired
	HospitalRepo hospitalRepo;
	
	@Autowired
	RoleRepo roleRepo;
	
	@Autowired
	DoctorRepo doctorRepo;
	
	@Autowired
	ReceptionRepo recaptionRepo;
	
	@Autowired
	ReceptionService receptionService;
	
	
	@Autowired
	UserRepo userRepo;
	
	@Autowired
	DepartmentRepo departmentRepo;
	
	@RequestMapping(value = { "", "/", "index" })
	public String receptionindex() {
		return "/Reception/index";
	}

	@RequestMapping("/{page}")
	public String receptionpage(@PathVariable String page) {
		return "/Reception/"+page;
	}
	
	@RequestMapping("/Receptionrecord/{id}")
	@ResponseBody
	public User findReception(@PathVariable long id) 
	{
		return userRepo.findById(id).orElse(null);
	}
	
	
	@RequestMapping("/changepassword")
	public String changePassword(@RequestParam("uid") long id,@RequestParam("password") String password,Model model) 
	{
		User user = userRepo.findById(id).orElse(null);
		
		user.setPassword(passwordEncoder.encode(password));
		userRepo.save(user);
		model.addAttribute("message", "Password Successfully Updated");
		
		return "Reception/Change-password";
	}
	
	@RequestMapping("/uploadImage")
	public String imageUpload(@RequestParam("uid") long id, @RequestParam("file") MultipartFile file) 
	{
		ReceptionModel reception = receptionService.findOne(id);
		System.out.println(id);
		if (file.isEmpty()) {
            
            return "redirect:/Reception/Imageupload";
        }

        try {

            // Get the file and save it somewhere
            byte[] bytes = file.getBytes();
            Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
            Files.write(path, bytes);

        } catch (IOException e) {
            e.printStackTrace();
        }
        String image = file.getOriginalFilename();
        System.out.println(image);
        reception.setImage(image);
        receptionService.save(reception);
		
		return "redirect:/Reception/index";
	}
	
	
	@RequestMapping("/Departmentadd")
	public String departmentadd(@ModelAttribute DepartmentModel department,Model model) 
	{
		departmentRepo.save(department);
		model.addAttribute("message", "Department Added");
		return "Reception/Add-department";
	}
	
	@RequestMapping("/Getdepartment/{id}")
	@ResponseBody
	public List<DepartmentModel> getDepartment(@PathVariable long id) 
	{
		return departmentRepo.getDepartment(id);
	}
	
	@RequestMapping("/Doctoradd")
	public String doctoradd(@ModelAttribute DoctorModel doctor,@RequestParam("password") String password,@RequestParam("email") String email,User user,Model model) 
	{
		Role r = roleRepo.findById((long) 2).orElse(null);
		
		Set<Role> roles = new HashSet<Role>();
		roles.add(r);
		
		
		
		user.setEmail(email);
		user.setPassword(passwordEncoder.encode(password));
		user.setRoles(roles);
		user.setResetToken(UUID.randomUUID().toString());
		
		doctor.setImage("admin.jpg");
		doctorRepo.save(doctor);
		user.setDoctorModel(doctor);
		userRepo.save(user);
		
		   MimeMessage message = sender.createMimeMessage();
		   MimeMessageHelper helper = new MimeMessageHelper(message);
		   try {
				helper.setTo(user.getEmail());
				helper.setText("Your User Name is : "+ email +" And Password is="+password);
				helper.setSubject("Mail For security info");
			} catch (MessagingException e) {
				e.printStackTrace();
				return "Error while sending mail ..";
			}
			sender.send(message);
		
		model.addAttribute("message", "Doctor Added");
		return "Reception/Doctor-reg";
	}
	
	
	@RequestMapping("/ViewAppointment/{id}")
	@ResponseBody
	public List<Booking> findHospitalAppointment(@PathVariable long id) 
	{
		return bookingRepo.getAppointmentByHospital(id);
	}
	
	@RequestMapping(value = "/View-Report" , method = RequestMethod.GET)
	public ModelAndView findPatientReport(@RequestParam("id") long id,Model m) 
	{
		
		
		ModelAndView mv = new ModelAndView("Reception/View-Report");
		mv.addObject("list", reportService.findByPatientId(id));
		return mv;
	}
	
	@RequestMapping(value = "/View-Patient", method = RequestMethod.GET)
	public ModelAndView findPatientDetails(@RequestParam("id") long id,Model m) 
	{
		
		ModelAndView mv = new ModelAndView("Reception/View-Patient");
		mv.addObject("list", patientService.findOne(id));
		return mv;
	}

}
