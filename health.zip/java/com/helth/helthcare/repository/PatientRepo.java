package com.helth.helthcare.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import com.helth.helthcare.model.PatientModel;

@Repository
public interface PatientRepo extends JpaRepository<PatientModel, Long> 
{
	@Query(value="update patient set image=?1 where patientid=?2",nativeQuery=true)
	public PatientModel updatePatient(MultipartFile file,long id);
	
	@Query(value="select * from patient where email=?1 and password=?2",nativeQuery=true)
	PatientModel getPatient(String email, String pass);
	
	@Query(value="update patient set password=?1 where patientid=?2",nativeQuery=true)
	public void updatepassword(String password,long id);
	
}
