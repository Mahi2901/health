
package Concept;

public class ClassConcept
{

	/*public static void main(String args[]) {    
	    System.out.println(fun()); 
	}  
	int fun() { 
	    return 20; 
	}  */

	/*public static void main(String args[]) { 
	       System.out.println(fun()); 
	   } 														//Compiler Error   static local variables are not allowed in Java
	   static int fun() { 
	       static int x= 0; 
	       return ++x; 
	   } */

	/*	public static void gfg(String s) 
	{     
	    System.out.println("String");  														 
	}															//	In this case of method Overloading, the most specific method is choosen at compile time.
	public static void gfg(Object o) 							//	As �java.lang.String� and �java.lang.Integer� is a more specific type than �java.lang.Object�,
	{															//	but between �java.lang.String� and �java.lang.Integer� none is more specific. 
	    System.out.println("Object"); 		
	} 
	public static void gfg(Integer i) 
	{ 
	    System.out.println("Integer"); 
	} 
	  
	public static void main(String args[]) 
	{ 
	    gfg(null); 
	} */

}
