package com.helth.helthcare.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="doctor")
public class DoctorModel 
{

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long doctorid;
	private String doctorname;
	private String mobile;	
	private String gender;
	private String address;
	private String image;
	
	@JsonIgnore
	@OneToOne(mappedBy="doctorModel")
	private User users;
	
	@ManyToOne
	@JoinColumn(name="stateid")
	private StateModel stateModel;
	
	@ManyToOne
	@JoinColumn(name="cityid")
	private CityModel cityModel;
	
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="hospitalid")
	private HospitalModel hospitalModel;

	
	@ManyToOne
	@JoinColumn(name="departmentid")
	private DepartmentModel departmentModel;

	public long getDoctorid() {
		return doctorid;
	}

	public void setDoctorid(long doctorid) {
		this.doctorid = doctorid;
	}

	public String getDoctorname() {
		return doctorname;
	}

	public void setDoctorname(String doctorname) {
		this.doctorname = doctorname;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}


	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public User getUsers() {
		return users;
	}

	public void setUsers(User users) {
		this.users = users;
	}

	public StateModel getStateModel() {
		return stateModel;
	}

	public void setStateModel(StateModel stateModel) {
		this.stateModel = stateModel;
	}

	public CityModel getCityModel() {
		return cityModel;
	}

	public void setCityModel(CityModel cityModel) {
		this.cityModel = cityModel;
	}

	public HospitalModel getHospitalModel() {
		return hospitalModel;
	}

	public void setHospitalModel(HospitalModel hospitalModel) {
		this.hospitalModel = hospitalModel;
	}

	public DepartmentModel getDepartmentModel() {
		return departmentModel;
	}

	public void setDepartmentModel(DepartmentModel departmentModel) {
		this.departmentModel = departmentModel;
	}

	
	
	
	
}
