/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package mahendra;

/**
 *
 * @author Student
 */
public class pra2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int r=2;
        double pi=3.14,area=0;
        area=4*pi*r*r;
        
        System.out.println("Area = " + area);
    }
    
}
