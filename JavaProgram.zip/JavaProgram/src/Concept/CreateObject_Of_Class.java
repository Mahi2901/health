package Concept;

public class CreateObject_Of_Class implements Cloneable
{
	@Override
    protected Object clone() throws CloneNotSupportedException 
    { 
        return super.clone(); 
    } 
	
	public CreateObject_Of_Class()
	{
		System.out.println("Hello");
	}
	String name = "Mahendra";
	public static void main(String args[])
	{
		/*CreateObject_Of_Class co = new CreateObject_Of_Class(); // new Keyword
		System.out.println(co.name);
*/
		/*try
        { 
            Class cls = Class.forName("CreateObject_Of_Class"); 
            CreateObject_Of_Class obj = 
                    (CreateObject_Of_Class) cls.newInstance(); 
            System.out.println(obj.name); 
        } 
        catch (ClassNotFoundException e) 
        { 
            e.printStackTrace(); 
        } 
        catch (InstantiationException e) 
        { 
            e.printStackTrace(); 
        } 
        catch (IllegalAccessException e) 
        { 
            e.printStackTrace(); 
        } */
		
		CreateObject_Of_Class obj1 = new CreateObject_Of_Class(); 
        try
        { 
        	CreateObject_Of_Class obj2 = (CreateObject_Of_Class) obj1.clone(); 
            System.out.println(obj2.name); 
        } 
        catch (CloneNotSupportedException e) 
        { 
            e.printStackTrace(); 
        } 
	}

}
