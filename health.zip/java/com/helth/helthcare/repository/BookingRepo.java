package com.helth.helthcare.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.helth.helthcare.model.Booking;

@Repository
public interface BookingRepo extends JpaRepository<Booking, Long> 
{
	/*
	 * @Query(value="select * from bookappointment where bookingid=?1",nativeQuery=
	 * true) Booking findBybookid(long id);
	 */
	
	@Query(value="select * from bookappointment where doctorid=?1",nativeQuery=true)
	List<Booking> getDoctorAppointment(long id);
	
	@Query(value="select * from bookappointment where patientid=?1",nativeQuery=true)
	List<Booking> getPatientAppointment(long id);
	
	@Query(value="select * from bookappointment where hospitalid=?1",nativeQuery=true)
	List<Booking> getAppointmentByHospital(long id);
	
	@Query(value="select count(*) from bookappointment where hospitalid=?1",nativeQuery=true)
	long getAppointment(long id);
	

}
