package com.helth.helthcare.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.helth.helthcare.model.ArticalModel;

@Repository
public interface ArticalRepo extends JpaRepository<ArticalModel, Long> 
{

	List<ArticalModel> findByArticaltype(String type);
	
	@Query(value="select * from artical where doctorid=?1",nativeQuery=true)
	List<ArticalModel> findByDoctorid(long id); 
	
}
