package com.helth.helthcare.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="recaption")
public class ReceptionModel {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long recaptionid;
	private String recaptionname;
	private String gender;
	private String image;
	private String mobile;
	
	
	
	public String getMobile() {
		return mobile;
	}


	public void setMobile(String mobile) {
		this.mobile = mobile;
	}


	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="hospitalid")
	private HospitalModel hospitalModel;
	
	@JsonIgnore
	@OneToOne(mappedBy="receptionModel")
	private User users;


	public long getRecaptionid() {
		return recaptionid;
	}


	public void setRecaptionid(long recaptionid) {
		this.recaptionid = recaptionid;
	}


	public String getRecaptionname() {
		return recaptionname;
	}


	public void setRecaptionname(String recaptionname) {
		this.recaptionname = recaptionname;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public HospitalModel getHospitalModel() {
		return hospitalModel;
	}


	public void setHospitalModel(HospitalModel hospitalModel) {
		this.hospitalModel = hospitalModel;
	}


	public User getUsers() {
		return users;
	}


	public void setUsers(User users) {
		this.users = users;
	}


	public String getImage() {
		return image;
	}


	public void setImage(String image) {
		this.image = image;
	}
	

}
