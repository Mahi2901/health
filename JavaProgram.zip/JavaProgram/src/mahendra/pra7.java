/* wite a java program that will Accept command-Line arguments and display the same. */

class pra7
{
   public static void main(String args[])
{
 String s=args[0];   //command Line argument
System.out.println("String is: "+s);
}
}