package com.helth.helthcare.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.helth.helthcare.model.HospitalModel;
import com.helth.helthcare.repository.HospitalRepo;

@Service
@Transactional
public class HospitalServiceImp implements HospitalService 
{
	@Autowired
	HospitalRepo hospitalRepo;
	
	@Override
	public HospitalModel save(HospitalModel h) {
		
		return hospitalRepo.save(h);
	}

}
