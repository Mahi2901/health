package com.helth.helthcare.service;

import java.util.List;

import com.helth.helthcare.model.ArticalModel;
import com.helth.helthcare.model.ReportModel;

public interface ReportService 
{
	public ReportModel save(ReportModel report);
	public ReportModel findById(long id);
	public List<ReportModel> findByDoctorId(long id);
	public List<ReportModel> findByPatientId(long id);
}
